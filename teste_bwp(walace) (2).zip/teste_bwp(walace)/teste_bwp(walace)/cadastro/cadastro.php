<?php
 include '../cabecalho.php';
?>


<body>

        
        <br>
        <h3>Cadastre-se</h3>
        <form class="ui large form" id="formulario" method='POST'>
          <div class="ui stacked segment">
            <div class="field">
              <div class="ui left input">
                <input type="text" name="nome" placeholder="Nome">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="email" name="email" placeholder="E-mail">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="number" name="cartaoSus" placeholder="Cartão SUS">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="tel" name="telefone" placeholder="Telefone">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="number" name="cpf" placeholder="CPF">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="date" name="dataNascimento" placeholder="Data de nascimento">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="password" name="senha" placeholder="Senha">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="password" name="confirmarSenha" placeholder="Confirmação da Senha">
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="number" name="cep" placeholder="CEP">
                <div class="ui left input" id="bairro">
                  <input type="text" name="bairro" placeholder="Bairro">
                </div>
              </div>
            </div>
            <div class="field">
              <div class="ui left input">
                <input type="text" name="rua" placeholder="Rua">
                <div class="ui left input" id="numero">
                  <input type="number" name="numero" placeholder="N°">
                </div>
              </div>
            </div>
            <div class="row">
              <a href="index.php"><div class="ui negative basic button">cancelar</div></a>
              <button class="ui primary basic button" type="submit">
              cadastrar
            </button>
            </div>
          </div>
</body>

</html>





	 
	