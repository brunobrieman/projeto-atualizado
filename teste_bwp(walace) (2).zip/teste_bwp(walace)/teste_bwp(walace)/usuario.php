<?php

include 'cabecalho.php';

?>

<!DOCTYPE html>
<html>

<link rel="stylesheet" type="text/css" href="css/usuario.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<body>

	<img class="ui medium circular image avatar_meio" src="imagens/img_avatar.png">

	<h4 class="ui horizontal divider header">
  <i class="tags icon"></i>
  Usuario
</h4>
<br>

<style>
* {box-sizing: border-box}

/* Set height of body and the document to 100% */
body, html {
    height: 100%;
    margin: 0;
    font-family: Arial;
}

/* Style tab links */
.tablink {
    background-color: #555;
    color: white;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    font-size: 17px;
    width: 25%;
}

.tablink:hover {
    background-color: #777;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
    color: white;
    display: none;
    padding: 100px 20px;
    height: 50%;
}

#Home {background-color: #BDBDBD;}
#News {background-color: #BDBDBD;}
#Contact {background-color: #BDBDBD;}
#About {background-color: #BDBDBD;}
</style>
</head>
<body>

<button class="tablink" onclick="openPage('Home', this, 'black')">perfil</button>
<button class="tablink" onclick="openPage('News', this, 'black')" id="defaultOpen">minhas resenhas</button>
<button class="tablink" onclick="openPage('Contact', this, 'black')">novas resenhas</button>
<button class="tablink" onclick="openPage('About', this, 'black')">About</button>

<div id="Home" class="tabcontent">
  <h1>Bem vindo Usuario!</h1>
  <h3>nome:</h3>
  <h3>Email:</h3>
  <h3>apelido:</h3>
  <h3>resenhas postadas:</h3>

</div>

<div id="News" class="tabcontent">
 <div class="ui six doubling cards">
  <div class="card">
    <div class="image">
      <img src="imagens/fifa10.jpg">
      <i class="trash icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="pencil icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="home icon" style="color: black; height:10%; margin-left: 18%;"></i>
    </div>
  </div>
  <div class="card">
    <div class="image">
      <img src="imagens/ufc.jpg">
      <i class="trash icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="pencil icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="home icon" style="color: black; height:10%; margin-left: 18%;"></i>
    </div>
  </div>
  <div class="card">
    <div class="image">
      <img src="imagens/nhl.jpg">
      <i class="trash icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="pencil icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="home icon" style="color: black; height:10%; margin-left: 18%;"></i>
    </div>
  </div>
  <div class="card">
    <div class="image">
      <img src="imagens/f1.jpg">
      <i class="trash icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="pencil icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="home icon" style="color: black; height:10%; margin-left: 18%;"></i>
    </div>
  </div>
  <div class="card">
    <div class="image">
      <img src="imagens/live.jpg">
      <i class="trash icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="pencil icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="home icon" style="color: black; height:10%; margin-left: 18%;"></i>
    </div>
  </div>
  <div class="card">
    <div class="image">
      <img src="imagens/Skate.jpg">
      <i class="trash icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="pencil icon" style="color: black; height:10%; margin-left: 18%;"></i>
      <i class="home icon" style="color: black; height:10%; margin-left: 18%;"></i>
    </div>
  </div>
</div>
</div>

<div id="Contact" class="tabcontent">

<div class="novas_reasenhas_usuario">
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	  <script type="text/javascript" href="Semantic/semantic.js"></script>
<div class="ui card">
  <div class="content">
    <div class="right floated meta">14h</div>
    <img class="ui avatar image icone_direita" src="imagens/pessoa.jpg"> 
    <p class="icones icone_direita">fifa</p> 
  </div>
  <div class="image">
    <img src="imagens/fifa10.jpg">

  </div>
  <div class="content">
    <span class="right floated">
      <i class="heart outline like icon icones"></i>
      <p class="icones icone_direita">17 likes</p>
    </span>
    <i class="comment icon icones icone_direita"></i>
    <p class="icones icone_direita"> 3 comments </p>
  </div>
  <div class="extra content">
    <div class="ui large transparent left icon input">
      <i class="heart outline icon"></i>
      <input type="text" placeholder="Add Comment...">
    </div>
  </div>
</div>
</div>


<div class="novas_reasenhas_usuario">
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	  <script type="text/javascript" href="Semantic/semantic.js"></script>
<div class="ui card">
  <div class="content">
    <div class="right floated meta">14h</div>
    <img class="ui avatar image icone_direita" src="imagens/pessoa.jpg"> 
    <p class="icones icone_direita">fifa</p> 
  </div>
  <div class="image">
    <img src="imagens/fifa10.jpg">

  </div>
  <div class="content">
    <span class="right floated">
      <i class="heart outline like icon icones"></i>
      <p class="icones icone_direita">17 likes</p>
    </span>
    <i class="comment icon icones icone_direita"></i>
    <p class="icones icone_direita"> 3 comments </p>
  </div>
  <div class="extra content">
    <div class="ui large transparent left icon input">
      <i class="heart outline icon"></i>
      <input type="text" placeholder="Add Comment...">
    </div>
  </div>
</div>
</div>



<div class="novas_reasenhas_usuario">
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	  <script type="text/javascript" href="Semantic/semantic.js"></script>
<div class="ui card">
  <div class="content">
    <div class="right floated meta">14h</div>
    <img class="ui avatar image icone_direita" src="imagens/pessoa.jpg"> 
    <p class="icones icone_direita">fifa</p> 
  </div>
  <div class="image">
    <img src="imagens/fifa10.jpg">

  </div>
  <div class="content">
    <span class="right floated">
      <i class="heart outline like icon icones"></i>
      <p class="icones icone_direita">17 likes</p>
    </span>
    <i class="comment icon icones icone_direita"></i>
    <p class="icones icone_direita"> 3 comments </p>
  </div>
  <div class="extra content">
    <div class="ui large transparent left icon input">
      <i class="heart outline icon"></i>
      <input type="text" placeholder="Add Comment...">
    </div>
  </div>
</div>
</div>
</div>

<div id="About" class="tabcontent">
  <h3>About</h3>
  <p>Who we are and what we do.</p>
</div>

<script>
function openPage(pageName,elmnt,color) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].style.backgroundColor = "";
    }
    document.getElementById(pageName).style.display = "block";
    elmnt.style.backgroundColor = color;

}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>



</body>
</html>