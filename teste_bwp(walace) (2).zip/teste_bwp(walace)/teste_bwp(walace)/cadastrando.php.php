<?php
include 'cabecalho.php';

?>

<body>


<section class="menu_esquerda99">
	
	<img class="pessoa123" src="imagens/pessoa.png">
<div class="olaaa">
	<style>
.vertical-menu {
    width: 200px;
}

.vertical-menu a {
    background-color: #eee;
    color: black;
    display: block;
    padding: 12px;
    text-decoration: none;
}

.vertical-menu a:hover {
    background-color: #ccc;
}

.vertical-menu a.active {
    background-color: #585858;
    color: white;
}
</style>
<div class="vertical-menu">
  <a href="#" class="active">Perfil</a>
  <a href="#">Editar foto</a>
  <a href="#">Favoritos</a>
  <a href="#">Amigos</a>
  <a href="#">Minhas resenhas</a>
</div>

</div>

</section>
	
<section class="section_direita">
<div class="pra_baixo">
	<img class="opaa" src="imagens/pessoa.png">
	<div class="separador">.</div>

	<h2 class="texto_wallace">Fifa</h2>
	<div class="separador">.</div>
	<img class="opa2" src="imagens/icone23.png">


	<img class="opa3" src="imagens/excluir209.png">


	<img class="opa4" src="imagens/visualizacao209.png">
</div>
</section>

	
	
</body>
</html>