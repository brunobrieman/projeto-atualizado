<!DOCTYPE html>
<html>
<head>
  <title>cadastrando...</title>
</head>
<body>



<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "usuario";
$link = mysqli_connect($host, $banco, $pass);
if (!$link) {
    die('Erro ao conectar ao banco: ' . mysql_error());
}
echo 'Conectado com sucesso';

?>


<?php


$nome = $_POST['nome'];
$email = $_POST['email'];
$apelido= $_POST['apelido'];
$senha = $_POST['senha'];
$confirmar = $_POST['confirmarSenha'];
$data=$_POST['dataNascimento'];

$sql="INSERT INTO usuario(nome,email,apelido,senha,confirmarSenha,dataNascimento) VALUES ('".$nome."', '".$email."','".$apelido."','".$senha."','".$confirmar."','".$data."')";

 





?>
</body>
</html>
