<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
  <script src="Semantic/semantic.min.js"></script>
  <script type="text/javascript" src="js.js"></script>
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
  <link rel="stylesheet" type="text/css" href="css/menu.css">
  <link rel="stylesheet" type="text/css" href="css/login.css">
  <link rel="stylesheet" type="text/css" href="css/trabalho.css">
  <link rel="stylesheet" type="text/css" href="css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="css/minhas_resenhas.css">
  <link rel="stylesheet" type="text/css" href="classifi_resenha.css">  
</head>
<body>
  <header>
    <div class="topnav" id="myTopnav">
      <a><img src="logo.png" id="logo_responsa"></a>
      <a href="index.php" class="active">Home</a>
     <a href="todasResenhas.php">Resenhas</a> 
      

      <a href="cadastroResenha.php">Cadastro</a>

      <a href="usuario.php">Usuário</a>
      <a href="javascript:void(0);" class="icon" onclick="myFunction()">
        <i class="fa fa-bars"></i>
      </a>
      <input class="pesquisar_menu" type="search" name="pesquisa" placeholder="pesquisar resenha">
      <a href="detalha_resenha.php?cod=1"><input type="submit" class="botao_menu_topo" value="Enviar"></a>
    </div>

<style type="text/css">
  .pesquisar_menu{
    margin-left: 40%;
    margin-top: 2%;
    width: 15%;
    height: 25px;
    float: left;
  }
  .botao_menu_topo{
    margin-left: 70%;
    height: 25px;
    float: right;
  }
</style>

    









  <script type="text/javascript">
    function myFunction() {
      var x = document.getElementById("myTopnav");
      if (x.className === "topnav") {
        x.className += " responsive";
      } else {
        x.className = "topnav";
      }
    }

  </script>
</header>
